Please fill out one of the templates on: https://github.com/cloudfoundry/cli/issues/new/choose to help us triage the issue and to provide context for your feature request. Failure to use the templates for the bug or feature request may result in immediate closure of the issue/request. Thanks. 

If you want to ask a question please contact us on the #cli channel on Cloud Foundry Slack.

