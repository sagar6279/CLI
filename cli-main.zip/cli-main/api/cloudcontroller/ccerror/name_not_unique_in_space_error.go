package ccerror

type NameNotUniqueInSpaceError struct {
	UnprocessableEntityError
}
