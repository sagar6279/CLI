package ccerror

type RouteNotUniqueError struct {
	UnprocessableEntityError
}
